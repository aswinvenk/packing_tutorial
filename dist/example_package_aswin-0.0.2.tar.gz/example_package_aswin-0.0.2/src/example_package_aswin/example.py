def add_one(number):
    """
    This will add 1 to your number
    """
    return number + 1

def add_numbers(a,b):
    """
    this will add your numbers
    """
    return a+b