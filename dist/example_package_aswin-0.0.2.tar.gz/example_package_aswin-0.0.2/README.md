Packaging tutorial
==================


# Adding 1 to a number
The function takes a value and returns your input +1
```python
>>> example.add_one(43)
44
```

# Adding two numbers
This function takes 2 numbers and adds them
```python
>>> example.add_numbers(43,44)
87
```

Created by Aswin Venkat <aswinvenk8@gmail.com>