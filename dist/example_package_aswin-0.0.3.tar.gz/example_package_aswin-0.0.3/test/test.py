from src.example_package_aswin import example
example.display_symbols()